package exam;

import java.util.*;

public class Q7 {

	public static void main(String[] args) {
		   HashMap<String,String> m=new HashMap<String,String>();    
		      
		      m.put("key1","TestVal1");    
		      m.put("Key2","TestVal2");    
		      m.put("Key3","TestVal1");
		      m.put("Key4","TestVal2");    
		      m.put("Key5","TestVal2");    
		      m.put("Key6","TestVal3");
		      System.out.println(m);	
		 
		          }
		      
	}


