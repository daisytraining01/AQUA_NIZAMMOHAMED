package exam;

import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;

public class Q1 //Write a program to demonstrate First In First Out and Last In First Out concept demonstration
{

	public static void main(String[] args) {
		   Queue<Integer> q1 = new LinkedList<>(); 
		   for (int i = 0; i < 5; i++) 
		   {
	            q1.add(i);
		   }
	        System.out.println(q1);
	        
	        //First in First out using Queue
	        
	        Stack<Integer> s1 = new Stack<Integer>(); 
	        
	        for (int i = 0; i < 5; i++) { 
	            s1.push(i); 
	        } 
	        for (int i = 0; i < 5; i++) { 
	            Integer s2 = s1.pop(); 
	            System.out.println(s2); 
	        } // Last in First Out using Stack
	        
	       /*
	        * Output
	        * [0, 1, 2, 3, 4]
4
3
2
1
0 
	        */
}
}
