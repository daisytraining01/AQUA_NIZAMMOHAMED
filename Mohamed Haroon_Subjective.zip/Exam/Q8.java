package exam;

public class Q8 implements One // implements form "One" interface
{
	
	public void addi(int a, int b) //Overloading
	{
		System.out.println(a+b);
	}
	public void addi(int a, int b,int c) //Overloading
	{
		System.out.println(a+b+c);
	}


	public static void main(String[] args) {
		Q8 q =new Q8();
		q.addi(1,2);//Overloading
		q.addi(1,2,3);//Overloading

	}

}
