package exam;

public class Q2 //Write a program to print Fibonacci Series using JAVA 
{

	public static void main(String[] args) {
		int i=5,out,out1 = 1;
		for (int j=1;j<=i;j++)
		{
			out=out1*j;
			out1=out;		
		}
System.out.println(out1);//120
	}

}
