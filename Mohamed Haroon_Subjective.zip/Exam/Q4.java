package exam;
//Write a program to demonstrate constructor, encapsulation and Inheritance .
class add 
{  
	private int out;//Encapsulation

	 int add1(int c,int d)
	 {
		 this.out=c*d;//Encapsulation
	 return(out);
	 }
}

public class Q4 extends add //Inheritance
{
  
	Q4() //constructor
	{
		System.out.println("I am constructor");
	}
	
	private int out1;//Encapsulation
	
		 int multi1(int a,int b)
		 {
			 this.out1=a+b;//Encapsulation
			 return out1;
		 }
		 
			public static void main(String[] args) {
				
				Q4 s=new Q4();
				System.out.println(s.add1(2, 2));
				System.out.println(s.multi1(5, 5)); // assessing both methods using Q4 object
				
/*
 * Output--
 * I am constructor
4
10*/
			}
		 
	}  
	
	



