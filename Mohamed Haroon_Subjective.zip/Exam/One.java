package exam;

public interface One {
	
	public static void addi(int a, int b)
	{
	
	}
	public static void addi(int a, int b,int c)
	{
		
	}

}
