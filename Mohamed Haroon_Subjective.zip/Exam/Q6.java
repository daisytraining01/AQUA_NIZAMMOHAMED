package exam;

public class Q6 //Write a method to check if input string is Palindrome?
{
	
	public static void main(String[] args) 
	{
		String a="madam",b = "";
		int l = a.length();
		for ( int i = l - 1; i >= 0; i-- )  
		{
	         b = b + a.charAt(i);
		}
		System.out.println(a);
		System.out.println(b);
		if (a.equals(b))
			System.out.println("Palindrome");
		else
			System.out.println("not");
	}
	
	/*
	 * madam
madam
Palindrome
	 */

}
