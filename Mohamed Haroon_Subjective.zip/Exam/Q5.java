package exam;

public class Q5

//Write a program that will remove a given characters from the string (String = �REST ASSURED� , remove characters �ST�  )

//Write a program to compare two strings using JAVA Program 

{

	public static void main(String[] args) {
		
		String s1= "REST ASSURED";	
		String [] s3={"S","T"};
		for(int i=0;i<s3.length;i++)
		{
		int p= s1.indexOf(s3[i]);
		s1=s1.substring(0, p) + s1.substring(p + 1);
		}
		System.out.println(s1);  //RE ASSURED
		
		//String Compare
		String str1="Maveric";
		String str2="Maveric";
		
		if (str1.equals(str2)) // String Compare
		{
			System.out.println("String Match");
		}
		else
		{
			System.out.println("String Not Match");
		}
		
		/* Output
		 * RE ASSURED
		 * String Match
		 */
		

	}

}
