package exam;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Q3 //Write a program to read all the lines from the text file. While printing, print only the alternate lines.
{

	public static void main(String[] args) {
		try {
			int count=0;
		      File myObj = new File("D:\\file.txt");
		      Scanner myReader = new Scanner(myObj);
		      while (myReader.hasNextLine()) //1.Hai 2.Maveric 3.Systems 4.Ltd
		      {
		    	  String data = myReader.nextLine();
		    	  if ((count % 2)==0)
		    	  {
		        System.out.println(data);//1.Hai 3.Systems
		    	  }
		    	  count++;
		      }
		      myReader.close();
		    } catch (FileNotFoundException e) {
		      System.out.println("An error occurred.");
		      e.printStackTrace();
		    }

	}

}
